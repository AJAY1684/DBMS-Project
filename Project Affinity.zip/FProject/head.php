<header id="header">


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3">
    <a href="Mmanage/manage.php" class="navbar-brand">
        <h3 class="px-5">
          <i class="fas fa-shopping-basket">Affinity</i>
            Demo Store
        </h3>
    </a>
    

    <button class="navbar-toggler" type="button"
    data-toggle="collapse"
    data-target="#navbarNavAltMarkup"
    aria-controls="navbarNavAltMarkup"
    aria-expanded="false"
    aria-label="Toggle navigation">

    <span class="navbar-toggler-icon"></span>



    


                
    </nav>






</header>