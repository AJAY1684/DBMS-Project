<!DOCTYPE html>
<body>
<html><!-- About Our page-->
<link rel="stylesheet" href=".\About Pics\about.css">

<div class="menu-bar">
    <br>
    <h1 style="height: fit-content;" ><b style="text-align: center;" style="font-size: xx-large;" style="font-style: inherit;"> Team Affinity </b></h1>
    <ul>
        <img src =".\About Pics\logo.png" class = "logo">
    </ul>
</div>
<br>
<marquee><b style="font-style: italic;">This website is designed by Team Affinity</b></marquee>
<div class="menu-bar2"><br>
    <h2 >Information About the Webpage</h2>
</div>

<div class="container">
    <img src=".\About Pics\aboutimg.jpg"  alt="">
    <br> <br>
    <div class="text">
     <p><b>
        This website is mainly designed to help and improve the connection between the 
        shopkeepers and the coustomers . Here in this wensite people can see the availabe 
        grosaries in their nearby shops without visiting them directly but by just sitting 
        in their houses . They can also add items to cart which they are going to buy 
        in the shop and they can directly go to their selected nearby shop to get their 
        selected items. This will same their time and will help them improve their degital 
        life. Not Only the coustomers shop keepers also get lot of beniits by this website.
     </b>
        
     </p>
    </div>
    <br><br><br><br><br><br><br><br><br>
    <img src=".\About Pics\aboutimg2.jpg">
    <br><br>
    <div class="text">
        <p> <b>The Benifits which coustomers are going to gain ny using this website are as 
            follows :<br>
     </b>       <ul style="list-style-type: align-self: start;;">
                <li> No need to waste much time to select their items in shop as they can 
                    select the items by directly sittng in their home </li>
                    <li>
                        They can add their liked items to cart and they can diectly visit the shop and get them 
                        directly by paying the amount
                    </li>
                    <li>
                        They can find their desired item in any shop availabe in their area
                    </li>
                    <li>
                        They can know all the items which are available in their nearby shops 
                        even with out visitin them directly.
                    </li>
            </ul>
        </p>
    </div>
    <br> <br> <br> <br> <br><br><br><br>
    <img src=".\About Pics\aboutimg3.jpg">
    <br><br>
    <div class="text">
        <b> The Benifits which the shopkeepers are going to gain are as follows :</b>
        <br>
        <ul style="list-style-type: lower-roman;">
            <li>They can update all newly arived items in website so that the coustomers who are 
                intrested can eazily find and buy then.
            </li>
            <li>
                They can provide offers to the products that are excess and too old and 
                can get them slod eazily
            </li>
            <li>
                They can improve their bussines althrough their locality as every one in their
                locality can see their shop and items availabe in their shop
            </li>
        </ul>
    </div>
    
</div>



</body>
</html>
